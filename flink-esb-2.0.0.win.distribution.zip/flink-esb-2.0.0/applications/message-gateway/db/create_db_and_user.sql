create database gateway;
CREATE USER 'gateway'@'localhost' IDENTIFIED BY 'pass4gateway';
GRANT ALL PRIVILEGES ON gateway.* TO 'gateway'@'%' IDENTIFIED BY 'pass4gateway';
